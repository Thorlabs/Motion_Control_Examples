version_number = "0.0.1"
document_revision = "NA"
release_date = "2025-8-11"

if __name__ == '__main__':
    print(version_number)
